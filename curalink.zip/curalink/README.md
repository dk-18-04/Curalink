# ⬡ Curalink — AI Medical Research Assistant

> An intelligent, research-backed health companion that retrieves, ranks, and reasons over peer-reviewed publications and clinical trials to deliver personalized, source-attributed medical insights.

![Curalink](https://img.shields.io/badge/Stack-MERN-00c2ff?style=flat-square) ![LLM](https://img.shields.io/badge/LLM-Ollama%20%2F%20Mistral-8b5cf6?style=flat-square) ![Sources](https://img.shields.io/badge/Sources-PubMed%20%7C%20OpenAlex%20%7C%20ClinicalTrials-10b981?style=flat-square)

---

## 🎯 What It Does

Curalink accepts structured patient context (name, disease, location) and natural language queries, then:

1. **Expands the query** intelligently using an LLM (e.g. `"deep brain stimulation"` → `"deep brain stimulation Parkinson's disease motor symptoms DBS therapy"`)
2. **Fetches a broad candidate pool** (50–200+ results) in parallel from 3 mandatory sources
3. **Ranks and filters** using a multi-factor scoring algorithm
4. **Generates a personalized, structured response** grounded strictly in retrieved evidence
5. **Maintains conversation context** for intelligent multi-turn follow-ups

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      REACT FRONTEND                          │
│  Sidebar │ ChatWindow │ ResearchPanel │ ContextModal         │
└─────────────────────┬───────────────────────────────────────┘
                      │ REST API (JSON)
┌─────────────────────▼───────────────────────────────────────┐
│                    EXPRESS BACKEND                            │
│                                                              │
│  POST /api/chat                                              │
│      │                                                       │
│      ▼                                                       │
│  ┌─────────────────────────────────────────────────────┐    │
│  │           Research Orchestrator Pipeline             │    │
│  │                                                      │    │
│  │  1. LLM Query Expansion (Ollama/Mistral)            │    │
│  │       "diabetes" + "insulin resistance"              │    │
│  │       → "Type 2 diabetes mellitus insulin           │    │
│  │          resistance glucose metabolism HbA1c"        │    │
│  │                                                      │    │
│  │  2. Parallel Fetch (broad pool 50–200 results)      │    │
│  │       ├── PubMed API        (~80 results)           │    │
│  │       ├── OpenAlex API      (~100 results)          │    │
│  │       └── ClinicalTrials.gov (~50 trials)           │    │
│  │                                                      │    │
│  │  3. Ranking Pipeline                                │    │
│  │       ├── Term frequency scoring                    │    │
│  │       ├── Disease relevance weighting               │    │
│  │       ├── Recency decay (newer = higher)            │    │
│  │       ├── Source credibility (PubMed +8)            │    │
│  │       ├── Open access bonus                         │    │
│  │       └── Abstract quality scoring                  │    │
│  │                                                      │    │
│  │  4. Final Output: Top 8 pubs + Top 6 trials         │    │
│  └─────────────────────────────────────────────────────┘    │
│      │                                                       │
│      ▼                                                       │
│  LLM Response Generation (Ollama/Mistral)                   │
│      → Structured markdown with citations                    │
│      → Personalized to patient context                       │
│      → Context-aware follow-up support                       │
│      │                                                       │
│      ▼                                                       │
│  MongoDB — Session + message history persistence             │
└─────────────────────────────────────────────────────────────┘
```

---

## 🧠 LLM Strategy

Curalink uses **Ollama with Mistral 7B** (open-source, runs locally):

| Task | Model Role |
|------|-----------|
| Query Expansion | Converts user intent + disease into rich PubMed-style search strings |
| Response Generation | Synthesizes retrieved evidence into structured markdown with citations |
| Follow-up Reasoning | Uses conversation history to resolve pronouns and implicit references |

**Fallback behavior**: If Ollama is unavailable, the system still works — it uses simple query concatenation for expansion and a template-based response builder with the same retrieved data.

---

## 📊 Retrieval Pipeline Details

### Why Depth-First?

The spec requires fetching a **broad candidate pool** before filtering. Curalink fetches:
- **PubMed**: 80 results via `esearch` → batch `efetch` (XML parsed)
- **OpenAlex**: 100 results with inverted-index abstract reconstruction
- **ClinicalTrials.gov**: Parallel calls for RECRUITING + general (deduplicated)

**Total pool**: typically 150–230 candidates  
**Final output**: Top 8 publications + Top 6 trials

### Ranking Factors

| Factor | Weight |
|--------|--------|
| Disease term frequency in title+abstract | +10 per term |
| Query term frequency (capped at 15/term) | +3 per occurrence |
| Recency: ≤1 year | +20 |
| Recency: ≤3 years | +15 |
| Recency: ≤5 years | +10 |
| PubMed source bonus | +8 |
| Abstract length >300 chars | +5 |
| Open Access | +3 |
| Has authors | +2 |

Clinical trials additionally scored by: status (RECRUITING=+20), contact info presence (+5), location presence (+3).

---

## 📁 Project Structure

```
curalink/
├── backend/
│   ├── server.js                    # Express app + MongoDB connection
│   ├── models/
│   │   └── Session.js               # Conversation session schema
│   ├── routes/
│   │   ├── chat.js                  # POST /api/chat — main endpoint
│   │   ├── sessions.js              # GET/DELETE /api/sessions
│   │   └── research.js              # GET /api/research (direct)
│   └── services/
│       ├── pubmedService.js         # PubMed esearch + efetch
│       ├── openAlexService.js       # OpenAlex works API
│       ├── clinicalTrialsService.js # ClinicalTrials.gov v2 API
│       ├── rankingService.js        # Multi-factor ranking algorithm
│       ├── llmService.js            # Ollama integration + fallback
│       └── researchOrchestrator.js  # Coordinates all services
├── frontend/
│   ├── public/index.html
│   └── src/
│       ├── App.js
│       ├── context/ChatContext.js   # Global state (useReducer)
│       ├── services/api.js          # Axios API client
│       ├── pages/MainLayout.js      # 3-panel layout
│       └── components/
│           ├── Sidebar.js           # Session history + context badge
│           ├── ChatWindow.js        # Message thread + input
│           ├── ResearchPanel.js     # Publications + trials cards
│           └── ContextModal.js      # Patient context form
├── docker-compose.yml
└── README.md
```

---

## 🚀 Setup & Running

### Prerequisites
- Node.js 18+
- MongoDB (Atlas free tier or local)
- [Ollama](https://ollama.ai) installed locally

### 1. Install Ollama + Pull Model
```bash
# Install Ollama from https://ollama.ai
ollama pull mistral
ollama serve   # runs on http://localhost:11434
```

### 2. Backend Setup
```bash
cd backend
npm install
cp .env.example .env
# Edit .env: set MONGODB_URI to your MongoDB connection string
npm run dev
```

### 3. Frontend Setup
```bash
cd frontend
npm install
npm start
```

App runs at **http://localhost:3000**

---

## 🐳 Docker Setup (Easiest)

```bash
# Edit docker-compose.yml: set MONGODB_URI
docker-compose up --build
```

---

## 🌐 Deployment

### Backend → Render.com (Free)
1. Push to GitHub
2. New Web Service → connect repo → set `Root Directory: backend`
3. Build: `npm install` | Start: `npm start`
4. Add environment variables from `.env.example`

### Frontend → Vercel (Free)
1. Import GitHub repo → set `Root Directory: frontend`
2. Set `REACT_APP_API_URL` to your Render backend URL
3. Deploy

### MongoDB → MongoDB Atlas (Free)
1. Create free cluster at [mongodb.com/atlas](https://mongodb.com/atlas)
2. Get connection string → paste in backend `MONGODB_URI`

---

## 💡 Example Queries

| Query | Disease Context |
|-------|----------------|
| "Latest treatment for lung cancer" | Lung Cancer |
| "Clinical trials for diabetes" | Type 2 Diabetes |
| "Top researchers in Alzheimer's disease" | Alzheimer's Disease |
| "Deep brain stimulation outcomes" | Parkinson's Disease |
| "Can I take Vitamin D?" | (follows up on lung cancer context) |

---

## ⚙️ Environment Variables

```env
# Backend (.env)
PORT=5000
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/curalink
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=mistral
FRONTEND_URL=http://localhost:3000
NODE_ENV=development

# Frontend (.env)
REACT_APP_API_URL=http://localhost:5000/api
```

---

## 🔬 Data Sources

| Source | API | Data |
|--------|-----|------|
| PubMed (NCBI) | `eutils.ncbi.nlm.nih.gov` | Peer-reviewed biomedical publications |
| OpenAlex | `api.openalex.org` | Open scholarly works, 250M+ papers |
| ClinicalTrials.gov | `clinicaltrials.gov/api/v2` | Ongoing and completed clinical trials |

---

## ⚠️ Disclaimer

Curalink is for **research and educational purposes only**. It does not provide medical advice. Always consult a qualified healthcare professional before making medical decisions.
