import React from 'react';
import { ChatProvider } from './context/ChatContext';
import MainLayout from './pages/MainLayout';

export default function App() {
  return (
    <ChatProvider>
      <MainLayout />
    </ChatProvider>
  );
}
