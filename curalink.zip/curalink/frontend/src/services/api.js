import axios from 'axios';

const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || '/api',
  timeout: 120000
});

export const sendMessage  = (payload) => api.post('/chat', payload).then(r => r.data);
export const getSessions  = ()         => api.get('/sessions').then(r => r.data);
export const getSession   = (id)       => api.get(`/sessions/${id}`).then(r => r.data);
export const deleteSession= (id)       => api.delete(`/sessions/${id}`);
export const healthCheck  = ()         => api.get('/health').then(r => r.data);

export default api;
