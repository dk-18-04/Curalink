import React, { useRef, useEffect, useState } from 'react';
import { useChat } from '../context/ChatContext';
import ReactMarkdown from 'react-markdown';
import styles from './ChatWindow.module.css';

const SUGGESTIONS = [
  'Latest treatment for lung cancer',
  'Clinical trials for Type 2 diabetes',
  'Top research in Alzheimer\'s disease',
  'Recent studies on heart disease',
  'Deep brain stimulation for Parkinson\'s',
];

export default function ChatWindow({ onOpenContext }) {
  const { messages, send, loading, error, expandedQuery, disease, patientName } = useChat();
  const [input, setInput] = useState('');
  const bottomRef = useRef(null);
  const textareaRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = () => {
    const msg = input.trim();
    if (!msg || loading) return;
    setInput('');
    send(msg);
  };

  const handleKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const isEmpty = messages.length === 0;

  return (
    <div className={styles.window}>
      {/* Top bar */}
      <div className={styles.topbar}>
        <div className={styles.topbarLeft}>
          <div className={styles.topbarTitle}>Medical Research Assistant</div>
          {expandedQuery && (
            <div className={styles.queryChip} title="Expanded search query">
              🔍 {expandedQuery.substring(0, 60)}{expandedQuery.length > 60 ? '…' : ''}
            </div>
          )}
        </div>
        <button className={styles.contextBtn} onClick={onOpenContext}>
          {patientName ? `👤 ${patientName}` : '+ Set Patient Context'}
        </button>
      </div>

      {/* Messages */}
      <div className={styles.messages}>
        {isEmpty && (
          <div className={styles.welcome}>
            <div className={styles.welcomeIcon}>⬡</div>
            <h1 className={styles.welcomeTitle}>Curalink</h1>
            <p className={styles.welcomeSub}>
              AI-powered medical research assistant. Ask about diseases, treatments, clinical trials, or research findings.
            </p>
            {!patientName && (
              <button className={styles.setContextBtn} onClick={onOpenContext}>
                Set Patient Context for Personalized Results →
              </button>
            )}
            <div className={styles.suggestions}>
              {SUGGESTIONS.map((s) => (
                <button key={s} className={styles.suggestion} onClick={() => { setInput(s); textareaRef.current?.focus(); }}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((msg) => (
          <div key={msg.id} className={`${styles.message} ${styles[msg.role]} fadeUp`}>
            <div className={styles.avatar}>
              {msg.role === 'user' ? '👤' : '⬡'}
            </div>
            <div className={styles.bubble}>
              {msg.role === 'assistant' ? (
                <div className="md">
                  <ReactMarkdown>{msg.content}</ReactMarkdown>
                </div>
              ) : (
                <p>{msg.content}</p>
              )}
              {msg.role === 'assistant' && msg.stats && (
                <div className={styles.msgMeta}>
                  <span>📚 {(msg.stats.pubmedCount || 0) + (msg.stats.openAlexCount || 0)} papers scanned</span>
                  <span>🧪 {msg.stats.trialsCount || 0} trials found</span>
                  <span>⏱ {((msg.stats.processingTime || 0) / 1000).toFixed(1)}s</span>
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className={`${styles.message} ${styles.assistant} fadeUp`}>
            <div className={styles.avatar}>⬡</div>
            <div className={styles.bubble}>
              <div className={styles.thinking}>
                <div className={styles.thinkingDots}>
                  <span /><span /><span />
                </div>
                <span className={styles.thinkingText}>Searching PubMed, OpenAlex & ClinicalTrials.gov…</span>
              </div>
            </div>
          </div>
        )}

        {error && (
          <div className={styles.errorBanner}>
            ⚠️ {error}
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className={styles.inputArea}>
        <div className={styles.inputWrap}>
          <textarea
            ref={textareaRef}
            className={styles.input}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Ask about a disease, treatment, or research topic…"
            rows={1}
          />
          <button
            className={`${styles.sendBtn} ${(!input.trim() || loading) ? styles.sendDisabled : ''}`}
            onClick={handleSend}
            disabled={!input.trim() || loading}
          >
            {loading ? <span className={styles.spinner} /> : '↑'}
          </button>
        </div>
        <div className={styles.inputHint}>Press Enter to send · Shift+Enter for new line</div>
      </div>
    </div>
  );
}
