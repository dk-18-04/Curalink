import React, { useState } from 'react';
import { useChat } from '../context/ChatContext';
import styles from './ResearchPanel.module.css';

const STATUS_COLORS = {
  RECRUITING: '#10b981',
  NOT_YET_RECRUITING: '#f59e0b',
  ACTIVE_NOT_RECRUITING: '#3b82f6',
  COMPLETED: '#8b5cf6',
  TERMINATED: '#ef4444',
  UNKNOWN: '#4a6280'
};

function PubCard({ pub, index }) {
  const [expanded, setExpanded] = useState(false);
  const isOpenAlex = pub.source?.includes('OpenAlex');

  return (
    <div className={styles.card}>
      <div className={styles.cardHeader}>
        <span className={`${styles.sourceBadge} ${isOpenAlex ? styles.openalex : styles.pubmed}`}>
          {isOpenAlex ? 'OpenAlex' : 'PubMed'}
        </span>
        <span className={styles.year}>{pub.year}</span>
        <span className={styles.score}>#{index + 1}</span>
      </div>

      <a href={pub.url} target="_blank" rel="noopener noreferrer" className={styles.cardTitle}>
        {pub.title}
      </a>

      {pub.authors?.length > 0 && (
        <div className={styles.authors}>
          {pub.authors.slice(0, 3).join(', ')}{pub.authors.length > 3 ? ` +${pub.authors.length - 3}` : ''}
        </div>
      )}

      {pub.abstract && (
        <>
          <p className={`${styles.abstract} ${expanded ? styles.expanded : ''}`}>
            {pub.abstract}
          </p>
          {pub.abstract.length > 160 && (
            <button className={styles.expandBtn} onClick={() => setExpanded(v => !v)}>
              {expanded ? 'Show less ▲' : 'Show more ▼'}
            </button>
          )}
        </>
      )}

      <div className={styles.cardFooter}>
        {pub.isOpenAccess && <span className={styles.oaBadge}>Open Access</span>}
        <a href={pub.url} target="_blank" rel="noopener noreferrer" className={styles.linkBtn}>
          View →
        </a>
      </div>
    </div>
  );
}

function TrialCard({ trial }) {
  const [expanded, setExpanded] = useState(false);
  const statusColor = STATUS_COLORS[trial.status] || STATUS_COLORS.UNKNOWN;

  return (
    <div className={styles.card}>
      <div className={styles.cardHeader}>
        <span className={styles.trialBadge}>ClinicalTrials.gov</span>
        <span className={styles.statusBadge} style={{ color: statusColor, borderColor: statusColor }}>
          {trial.status?.replace(/_/g, ' ')}
        </span>
      </div>

      <a href={trial.url} target="_blank" rel="noopener noreferrer" className={styles.cardTitle}>
        {trial.title}
      </a>

      <div className={styles.trialMeta}>
        {trial.phase && trial.phase !== 'N/A' && (
          <span className={styles.metaTag}>Phase: {trial.phase}</span>
        )}
        {trial.studyType && (
          <span className={styles.metaTag}>{trial.studyType}</span>
        )}
      </div>

      <p className={`${styles.abstract} ${expanded ? styles.expanded : ''}`}>
        {trial.summary}
      </p>
      {trial.summary?.length > 160 && (
        <button className={styles.expandBtn} onClick={() => setExpanded(v => !v)}>
          {expanded ? 'Show less ▲' : 'Show more ▼'}
        </button>
      )}

      {expanded && (
        <>
          {trial.eligibility && trial.eligibility !== 'Not specified' && (
            <div className={styles.section}>
              <div className={styles.sectionLabel}>Eligibility</div>
              <p className={styles.sectionText}>{trial.eligibility}</p>
            </div>
          )}

          {(trial.minAge || trial.maxAge || trial.sex) && (
            <div className={styles.section}>
              <div className={styles.sectionLabel}>Demographics</div>
              <div className={styles.trialMeta}>
                {trial.minAge && <span className={styles.metaTag}>Min: {trial.minAge}</span>}
                {trial.maxAge && <span className={styles.metaTag}>Max: {trial.maxAge}</span>}
                {trial.sex && <span className={styles.metaTag}>{trial.sex}</span>}
              </div>
            </div>
          )}

          {trial.locations?.length > 0 && (
            <div className={styles.section}>
              <div className={styles.sectionLabel}>Locations</div>
              {trial.locations.map((l, i) => (
                <div key={i} className={styles.location}>
                  📍 {[l.facility, l.city, l.country].filter(Boolean).join(', ')}
                </div>
              ))}
            </div>
          )}

          {(trial.contact?.email || trial.contact?.phone || trial.contact?.name) && (
            <div className={styles.section}>
              <div className={styles.sectionLabel}>Contact</div>
              {trial.contact.name && <div className={styles.contactLine}>👤 {trial.contact.name}</div>}
              {trial.contact.phone && <div className={styles.contactLine}>📞 {trial.contact.phone}</div>}
              {trial.contact.email && (
                <a href={`mailto:${trial.contact.email}`} className={styles.contactLine}>
                  ✉️ {trial.contact.email}
                </a>
              )}
            </div>
          )}
        </>
      )}

      <div className={styles.cardFooter}>
        <span className={styles.nctId}>{trial.id}</span>
        <a href={trial.url} target="_blank" rel="noopener noreferrer" className={styles.linkBtn}>
          Full Details →
        </a>
      </div>
    </div>
  );
}

export default function ResearchPanel() {
  const { currentPublications, currentTrials, currentStats, expandedQuery } = useChat();
  const [tab, setTab] = useState('publications');

  const pubCount   = currentPublications.length;
  const trialCount = currentTrials.length;

  return (
    <div className={styles.panel}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.headerTop}>
          <span className={styles.headerTitle}>Research Results</span>
          {currentStats && (
            <span className={styles.processingTime}>
              {((currentStats.processingTime || 0) / 1000).toFixed(1)}s
            </span>
          )}
        </div>
        {expandedQuery && (
          <div className={styles.expandedQuery}>
            <span className={styles.eqLabel}>Query:</span>
            <span className={styles.eqText}>{expandedQuery}</span>
          </div>
        )}
        {currentStats && (
          <div className={styles.stats}>
            <span>📚 {(currentStats.pubmedCount || 0) + (currentStats.openAlexCount || 0)} papers scanned</span>
            <span>🧪 {currentStats.trialsCount || 0} trials found</span>
          </div>
        )}
      </div>

      {/* Tabs */}
      <div className={styles.tabs}>
        <button
          className={`${styles.tab} ${tab === 'publications' ? styles.tabActive : ''}`}
          onClick={() => setTab('publications')}
        >
          Publications <span className={styles.tabCount}>{pubCount}</span>
        </button>
        <button
          className={`${styles.tab} ${tab === 'trials' ? styles.tabActive : ''}`}
          onClick={() => setTab('trials')}
        >
          Clinical Trials <span className={styles.tabCount}>{trialCount}</span>
        </button>
      </div>

      {/* Content */}
      <div className={styles.content}>
        {tab === 'publications' && (
          pubCount === 0
            ? <div className={styles.empty}>No publications found for this query.</div>
            : currentPublications.map((pub, i) => <PubCard key={pub.id || i} pub={pub} index={i} />)
        )}
        {tab === 'trials' && (
          trialCount === 0
            ? <div className={styles.empty}>No clinical trials found for this query.</div>
            : currentTrials.map((trial, i) => <TrialCard key={trial.id || i} trial={trial} />)
        )}
      </div>
    </div>
  );
}
