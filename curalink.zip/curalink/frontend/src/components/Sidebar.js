import React, { useState } from 'react';
import { useChat } from '../context/ChatContext';
import styles from './Sidebar.module.css';

export default function Sidebar({ onNewContext }) {
  const { sessions, sessionId, loadSession, newChat, removeSession, patientName, disease, loadSessions } = useChat();
  const [collapsed, setCollapsed] = useState(false);

  const handleLoad = async (s) => {
    const { getSession } = await import('../services/api');
    const full = await getSession(s.sessionId);
    loadSession(full);
  };

  const handleDelete = async (e, id) => {
    e.stopPropagation();
    if (window.confirm('Delete this conversation?')) {
      await removeSession(id);
    }
  };

  if (collapsed) {
    return (
      <div className={styles.collapsed}>
        <button className={styles.collapseBtn} onClick={() => setCollapsed(false)} title="Expand sidebar">☰</button>
        <button className={styles.newBtn} onClick={newChat} title="New chat">✦</button>
      </div>
    );
  }

  return (
    <div className={styles.sidebar}>
      {/* Header */}
      <div className={styles.header}>
        <div className={styles.logo}>
          <span className={styles.logoIcon}>⬡</span>
          <span className={styles.logoText}>Curalink</span>
        </div>
        <button className={styles.collapseBtn} onClick={() => setCollapsed(true)} title="Collapse">‹</button>
      </div>

      {/* Patient context badge */}
      {(patientName || disease) && (
        <div className={styles.contextBadge} onClick={onNewContext}>
          <div className={styles.contextIcon}>👤</div>
          <div className={styles.contextInfo}>
            <div className={styles.contextName}>{patientName || 'Anonymous'}</div>
            {disease && <div className={styles.contextDisease}>{disease}</div>}
          </div>
          <span className={styles.editIcon}>✎</span>
        </div>
      )}

      {/* New chat button */}
      <button className={styles.newChatBtn} onClick={() => { newChat(); onNewContext(); }}>
        <span>+</span> New Research Session
      </button>

      {/* History */}
      <div className={styles.historyLabel}>Recent Sessions</div>
      <div className={styles.history}>
        {sessions.length === 0 && (
          <div className={styles.empty}>No sessions yet.<br />Start by asking a question.</div>
        )}
        {sessions.map((s) => (
          <div
            key={s.sessionId}
            className={`${styles.sessionItem} ${s.sessionId === sessionId ? styles.active : ''}`}
            onClick={() => handleLoad(s)}
          >
            <div className={styles.sessionMeta}>
              <span className={styles.sessionName}>{s.patientName || 'Anonymous'}</span>
              {s.disease && <span className={styles.sessionDisease}>{s.disease}</span>}
            </div>
            <div className={styles.sessionPreview}>{s.preview || 'No messages'}</div>
            <div className={styles.sessionFooter}>
              <span className={styles.sessionDate}>{new Date(s.updatedAt).toLocaleDateString()}</span>
              <button className={styles.deleteBtn} onClick={(e) => handleDelete(e, s.sessionId)}>✕</button>
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className={styles.footer}>
        <div className={styles.footerText}>Powered by PubMed · OpenAlex · ClinicalTrials.gov</div>
      </div>
    </div>
  );
}
