import React, { useState } from 'react';
import { useChat } from '../context/ChatContext';
import styles from './ContextModal.module.css';

export default function ContextModal({ onClose }) {
  const { setContext, patientName: pn, disease: dis, location: loc } = useChat();

  const [name, setName]     = useState(pn  || '');
  const [disease, setDisease] = useState(dis || '');
  const [location, setLocation] = useState(loc || '');

  const handleSave = () => {
    setContext(name.trim(), disease.trim(), location.trim());
    onClose();
  };

  return (
    <div className={styles.overlay} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className={styles.modal}>
        <div className={styles.modalHeader}>
          <div className={styles.modalTitle}>
            <span className={styles.modalIcon}>👤</span>
            Patient Context
          </div>
          <button className={styles.closeBtn} onClick={onClose}>✕</button>
        </div>

        <p className={styles.modalDesc}>
          Setting patient context helps Curalink personalize research results, target relevant clinical trials, and generate tailored insights.
        </p>

        <div className={styles.fields}>
          <div className={styles.field}>
            <label className={styles.label}>Patient Name</label>
            <input
              className={styles.input}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. John Smith"
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Disease / Condition of Interest <span className={styles.required}>*</span></label>
            <input
              className={styles.input}
              value={disease}
              onChange={(e) => setDisease(e.target.value)}
              placeholder="e.g. Parkinson's disease, lung cancer, Type 2 diabetes"
            />
          </div>

          <div className={styles.field}>
            <label className={styles.label}>Location (optional)</label>
            <input
              className={styles.input}
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Toronto, Canada"
            />
            <span className={styles.hint}>Used to find nearby clinical trials</span>
          </div>
        </div>

        <div className={styles.actions}>
          <button className={styles.cancelBtn} onClick={onClose}>Cancel</button>
          <button className={styles.saveBtn} onClick={handleSave}>
            Save Context →
          </button>
        </div>

        <div className={styles.disclaimer}>
          ⚠️ No personal health data is stored permanently. This context is used only to improve research relevance within your current session.
        </div>
      </div>
    </div>
  );
}
