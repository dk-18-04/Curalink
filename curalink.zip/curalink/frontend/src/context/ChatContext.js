import React, { createContext, useContext, useReducer, useCallback } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { sendMessage, getSessions, deleteSession } from '../services/api';

const ChatContext = createContext(null);

const initialState = {
  sessionId: null,
  messages: [],
  patientName: '',
  disease: '',
  location: '',
  loading: false,
  error: null,
  sessions: [],
  currentPublications: [],
  currentTrials: [],
  currentStats: null,
  expandedQuery: ''
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_CONTEXT':
      return { ...state, patientName: action.patientName, disease: action.disease, location: action.location };
    case 'SEND_START':
      return { ...state, loading: true, error: null,
        messages: [...state.messages, { id: uuidv4(), role: 'user', content: action.content, timestamp: new Date() }] };
    case 'SEND_SUCCESS':
      return {
        ...state, loading: false,
        sessionId: action.sessionId,
        currentPublications: action.publications,
        currentTrials: action.clinicalTrials,
        currentStats: action.stats,
        expandedQuery: action.expandedQuery,
        messages: [...state.messages, {
          id: uuidv4(), role: 'assistant', content: action.response, timestamp: new Date(),
          publications: action.publications, clinicalTrials: action.clinicalTrials,
          stats: action.stats, expandedQuery: action.expandedQuery
        }]
      };
    case 'SEND_ERROR':
      return { ...state, loading: false, error: action.error };
    case 'LOAD_SESSION':
      return {
        ...state, sessionId: action.session.sessionId,
        patientName: action.session.patientName || '',
        disease: action.session.disease || '',
        location: action.session.location || '',
        messages: action.session.messages.map(m => ({
          id: uuidv4(), role: m.role, content: m.content, timestamp: m.timestamp,
          publications: m.metadata?.publications || [],
          clinicalTrials: m.metadata?.clinicalTrials || [],
          stats: m.metadata?.stats,
          expandedQuery: m.metadata?.expandedQuery
        })),
        currentPublications: action.session.messages.filter(m => m.role === 'assistant').slice(-1)[0]?.metadata?.publications || [],
        currentTrials: action.session.messages.filter(m => m.role === 'assistant').slice(-1)[0]?.metadata?.clinicalTrials || [],
      };
    case 'NEW_CHAT':
      return { ...initialState, sessions: state.sessions };
    case 'SET_SESSIONS':
      return { ...state, sessions: action.sessions };
    case 'CLEAR_ERROR':
      return { ...state, error: null };
    default:
      return state;
  }
}

export function ChatProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const send = useCallback(async (message) => {
    dispatch({ type: 'SEND_START', content: message });
    try {
      const data = await sendMessage({
        sessionId: state.sessionId,
        message,
        patientName: state.patientName,
        disease: state.disease,
        location: state.location
      });
      dispatch({ type: 'SEND_SUCCESS', ...data });
    } catch (err) {
      dispatch({ type: 'SEND_ERROR', error: err.response?.data?.error || err.message || 'Something went wrong' });
    }
  }, [state.sessionId, state.patientName, state.disease, state.location]);

  const setContext = useCallback((patientName, disease, location) => {
    dispatch({ type: 'SET_CONTEXT', patientName, disease, location });
  }, []);

  const loadSessions = useCallback(async () => {
    try {
      const sessions = await getSessions();
      dispatch({ type: 'SET_SESSIONS', sessions });
    } catch {}
  }, []);

  const loadSession = useCallback((session) => {
    dispatch({ type: 'LOAD_SESSION', session });
  }, []);

  const newChat = useCallback(() => dispatch({ type: 'NEW_CHAT' }), []);

  const removeSession = useCallback(async (id) => {
    await deleteSession(id);
    await loadSessions();
  }, [loadSessions]);

  return (
    <ChatContext.Provider value={{ ...state, send, setContext, loadSessions, loadSession, newChat, removeSession }}>
      {children}
    </ChatContext.Provider>
  );
}

export const useChat = () => useContext(ChatContext);
