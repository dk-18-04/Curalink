import React, { useState, useEffect } from 'react';
import { useChat } from '../context/ChatContext';
import Sidebar from '../components/Sidebar';
import ChatWindow from '../components/ChatWindow';
import ResearchPanel from '../components/ResearchPanel';
import ContextModal from '../components/ContextModal';
import styles from './MainLayout.module.css';

export default function MainLayout() {
  const { loadSessions, currentPublications, currentTrials, messages } = useChat();
  const [showContext, setShowContext] = useState(false);
  const [researchOpen, setResearchOpen] = useState(false);

  useEffect(() => { loadSessions(); }, [loadSessions]);

  // Auto-open research panel when results arrive
  useEffect(() => {
    if (currentPublications.length > 0 || currentTrials.length > 0) {
      setResearchOpen(true);
    }
  }, [currentPublications, currentTrials]);

  const hasResults = currentPublications.length > 0 || currentTrials.length > 0;

  return (
    <div className={styles.layout}>
      <Sidebar onNewContext={() => setShowContext(true)} />

      <main className={styles.main}>
        <ChatWindow onOpenContext={() => setShowContext(true)} />
      </main>

      {hasResults && (
        <aside className={`${styles.aside} ${researchOpen ? styles.asideOpen : styles.asideClosed}`}>
          <button className={styles.asideToggle} onClick={() => setResearchOpen(v => !v)}>
            {researchOpen ? '›' : '‹'}
            {!researchOpen && <span className={styles.asideBadge}>{currentPublications.length + currentTrials.length}</span>}
          </button>
          {researchOpen && <ResearchPanel />}
        </aside>
      )}

      {showContext && <ContextModal onClose={() => setShowContext(false)} />}
    </div>
  );
}
