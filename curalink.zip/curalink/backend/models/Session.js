const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  role: { type: String, enum: ['user', 'assistant'], required: true },
  content: { type: String, required: true },
  timestamp: { type: Date, default: Date.now },
  metadata: {
    publications: [mongoose.Schema.Types.Mixed],
    clinicalTrials: [mongoose.Schema.Types.Mixed],
    expandedQuery: String,
    processingTime: Number,
    stats: mongoose.Schema.Types.Mixed
  }
});

const SessionSchema = new mongoose.Schema({
  sessionId:   { type: String, required: true, unique: true, index: true },
  patientName: { type: String, default: 'Anonymous' },
  disease:     { type: String, default: '' },
  location:    { type: String, default: '' },
  messages:    [MessageSchema],
  createdAt:   { type: Date, default: Date.now },
  updatedAt:   { type: Date, default: Date.now }
});

SessionSchema.pre('save', function (next) { this.updatedAt = new Date(); next(); });

module.exports = mongoose.model('Session', SessionSchema);
