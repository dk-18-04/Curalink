const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const Session = require('../models/Session');
const { fetchAndRankResearch } = require('../services/researchOrchestrator');
const { generateMedicalResponse } = require('../services/llmService');

// POST /api/chat
router.post('/', async (req, res) => {
  try {
    const { sessionId, message, patientName, disease, location } = req.body;
    if (!message) return res.status(400).json({ error: 'Message is required' });

    const sid = sessionId || uuidv4();

    // Get or create session
    let session = await Session.findOne({ sessionId: sid });
    if (!session) {
      session = new Session({ sessionId: sid, patientName, disease, location });
    } else {
      if (patientName) session.patientName = patientName;
      if (disease) session.disease = disease;
      if (location) session.location = location;
    }

    session.messages.push({ role: 'user', content: message });

    const effectiveDisease = disease || session.disease || '';
    const effectiveLocation = location || session.location || '';

    // Full research pipeline
    const research = await fetchAndRankResearch({
      query: message,
      disease: effectiveDisease,
      location: effectiveLocation
    });

    // Build conversation history for context
    const history = session.messages.slice(-8).map((m) => ({ role: m.role, content: m.content }));

    // Generate AI response
    const aiText = await generateMedicalResponse({
      userQuery: message,
      disease: effectiveDisease,
      patientName: session.patientName,
      location: effectiveLocation,
      publications: research.publications,
      clinicalTrials: research.clinicalTrials,
      conversationHistory: history
    });

    // Save assistant message with metadata
    session.messages.push({
      role: 'assistant',
      content: aiText,
      metadata: {
        publications: research.publications,
        clinicalTrials: research.clinicalTrials,
        expandedQuery: research.expandedQuery,
        processingTime: research.stats.processingTime,
        stats: research.stats
      }
    });

    await session.save();

    res.json({
      sessionId: sid,
      response: aiText,
      publications: research.publications,
      clinicalTrials: research.clinicalTrials,
      expandedQuery: research.expandedQuery,
      stats: research.stats
    });
  } catch (err) {
    console.error('Chat route error:', err);
    res.status(500).json({ error: 'Failed to process request', details: err.message });
  }
});

module.exports = router;
