const express = require('express');
const router = express.Router();
const Session = require('../models/Session');

// GET all sessions (for sidebar history)
router.get('/', async (req, res) => {
  try {
    const sessions = await Session.find({}, 'sessionId patientName disease updatedAt messages')
      .sort({ updatedAt: -1 }).limit(30);
    res.json(sessions.map((s) => ({
      sessionId: s.sessionId,
      patientName: s.patientName || 'Anonymous',
      disease: s.disease || '',
      updatedAt: s.updatedAt,
      messageCount: s.messages.length,
      preview: s.messages.find((m) => m.role === 'user')?.content?.substring(0, 80) || ''
    })));
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET single session
router.get('/:sessionId', async (req, res) => {
  try {
    const session = await Session.findOne({ sessionId: req.params.sessionId });
    if (!session) return res.status(404).json({ error: 'Session not found' });
    res.json(session);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE session
router.delete('/:sessionId', async (req, res) => {
  try {
    await Session.deleteOne({ sessionId: req.params.sessionId });
    res.json({ success: true });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
