const express = require('express');
const router = express.Router();
const { fetchAndRankResearch } = require('../services/researchOrchestrator');

router.get('/', async (req, res) => {
  try {
    const { query, disease, location } = req.query;
    if (!query && !disease) return res.status(400).json({ error: 'query or disease required' });
    const results = await fetchAndRankResearch({ query: query || disease, disease: disease || '', location: location || '' });
    res.json(results);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
