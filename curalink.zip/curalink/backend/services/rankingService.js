const STOP = new Set(['and','or','the','in','of','for','with','a','an','is','are','was','to','from','on','at','by','as']);

function extractTerms(query) {
  return query.toLowerCase().split(/[\s+,;]+/).filter((t) => t.length > 3 && !STOP.has(t)).slice(0, 12);
}

function scorePublication(pub, terms, disease) {
  let score = 0;
  const text = `${pub.title} ${pub.abstract}`.toLowerCase();
  const diseaseTerms = (disease || '').toLowerCase().split(/\s+/);

  for (const t of diseaseTerms) if (t.length > 2 && text.includes(t)) score += 10;
  for (const t of terms) {
    const count = (text.match(new RegExp(t, 'gi')) || []).length;
    score += Math.min(count * 3, 15);
  }

  const year = parseInt(pub.year);
  if (!isNaN(year)) {
    const age = new Date().getFullYear() - year;
    if (age <= 1) score += 20;
    else if (age <= 3) score += 15;
    else if (age <= 5) score += 10;
    else if (age <= 10) score += 5;
  }

  if (pub.source === 'PubMed') score += 8;
  if (pub.isOpenAccess) score += 3;
  if (pub.abstract && pub.abstract.length > 300) score += 5;
  if ((pub.authors || []).length > 0) score += 2;

  return score;
}

function scoreTrial(trial, terms, disease) {
  let score = 0;
  const text = `${trial.title} ${trial.summary} ${trial.eligibility}`.toLowerCase();
  const diseaseTerms = (disease || '').toLowerCase().split(/\s+/);

  for (const t of diseaseTerms) if (t.length > 2 && text.includes(t)) score += 10;
  for (const t of terms) if (text.includes(t)) score += 5;

  const statusScore = { RECRUITING: 20, NOT_YET_RECRUITING: 15, ACTIVE_NOT_RECRUITING: 10, COMPLETED: 5 };
  score += statusScore[trial.status] || 0;

  if (trial.contact?.email || trial.contact?.phone) score += 5;
  if ((trial.locations || []).length > 0) score += 3;

  return score;
}

function rankPublications(pubs, query, disease, topN = 8) {
  const terms = extractTerms(query);
  const scored = pubs.map((p) => ({ ...p, relevanceScore: scorePublication(p, terms, disease) }));
  scored.sort((a, b) => b.relevanceScore - a.relevanceScore);

  // Deduplicate by title
  const seen = new Set();
  return scored.filter((p) => {
    const key = p.title.toLowerCase().substring(0, 60);
    if (seen.has(key)) return false;
    seen.add(key); return true;
  }).slice(0, topN);
}

function rankTrials(trials, query, disease, topN = 6) {
  const terms = extractTerms(query);
  const scored = trials.map((t) => ({ ...t, relevanceScore: scoreTrial(t, terms, disease) }));
  scored.sort((a, b) => b.relevanceScore - a.relevanceScore);
  return scored.slice(0, topN);
}

module.exports = { rankPublications, rankTrials, extractTerms };
