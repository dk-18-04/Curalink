const { searchPubMed } = require('./pubmedService');
const { searchOpenAlex } = require('./openAlexService');
const { searchClinicalTrials } = require('./clinicalTrialsService');
const { rankPublications, rankTrials } = require('./rankingService');
const { expandQuery } = require('./llmService');

async function fetchAndRankResearch({ query, disease, location = '' }) {
  const start = Date.now();

  // 1. Expand query
  console.log(`🔍 Expanding query: "${query}" | disease: "${disease}"`);
  const expandedQuery = await expandQuery(query, disease);
  console.log(`📝 Expanded: "${expandedQuery}"`);

  // 2. Fetch broad pool from all 3 sources in parallel
  const [pubmedRes, openAlexRes, trialsRes] = await Promise.allSettled([
    searchPubMed(expandedQuery, 80),
    searchOpenAlex(expandedQuery, 100),
    searchClinicalTrials(disease || query, query, location)
  ]);

  const pubmed   = pubmedRes.status === 'fulfilled'   ? pubmedRes.value   : [];
  const openalex = openAlexRes.status === 'fulfilled' ? openAlexRes.value : [];
  const trials   = trialsRes.status === 'fulfilled'   ? trialsRes.value   : [];

  console.log(`📊 Pool: PubMed=${pubmed.length} | OpenAlex=${openalex.length} | Trials=${trials.length}`);

  // 3. Merge and rank
  const allPubs = [...pubmed, ...openalex];
  const topPubs   = rankPublications(allPubs, expandedQuery, disease || query, 8);
  const topTrials = rankTrials(trials, expandedQuery, disease || query, 6);

  const processingTime = Date.now() - start;
  console.log(`✅ Final: ${topPubs.length} pubs, ${topTrials.length} trials (${processingTime}ms)`);

  return {
    expandedQuery,
    publications: topPubs,
    clinicalTrials: topTrials,
    stats: {
      totalCandidates: allPubs.length,
      pubmedCount: pubmed.length,
      openAlexCount: openalex.length,
      trialsCount: trials.length,
      processingTime
    }
  };
}

module.exports = { fetchAndRankResearch };
