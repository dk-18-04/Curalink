const axios = require('axios');
const xml2js = require('xml2js');

const BASE = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils';

async function searchPubMed(query, maxResults = 100) {
  try {
    // Step 1: Get IDs
    const searchRes = await axios.get(`${BASE}/esearch.fcgi`, {
      params: { db: 'pubmed', term: query, retmax: maxResults, sort: 'pub date', retmode: 'json' },
      timeout: 15000
    });
    const idList = searchRes.data?.esearchresult?.idlist || [];
    if (!idList.length) return [];

    // Step 2: Fetch details via XML
    const fetchRes = await axios.get(`${BASE}/efetch.fcgi`, {
      params: { db: 'pubmed', id: idList.slice(0, 80).join(','), retmode: 'xml' },
      timeout: 20000
    });

    const parser = new xml2js.Parser({ explicitArray: false });
    const parsed = await parser.parseStringPromise(fetchRes.data);
    const raw = parsed?.PubmedArticleSet?.PubmedArticle;
    if (!raw) return [];

    const articles = Array.isArray(raw) ? raw : [raw];

    return articles.map((article) => {
      try {
        const medline = article?.MedlineCitation;
        const art = medline?.Article;
        const pmid = medline?.PMID?._ || medline?.PMID;

        // Authors
        const rawAuthors = art?.AuthorList?.Author;
        const authArr = rawAuthors ? (Array.isArray(rawAuthors) ? rawAuthors : [rawAuthors]) : [];
        const authors = authArr.slice(0, 5).map((a) => `${a?.LastName || ''} ${a?.ForeName || a?.Initials || ''}`.trim()).filter(Boolean);

        // Abstract
        const abNode = art?.Abstract?.AbstractText;
        let abstract = '';
        if (typeof abNode === 'string') abstract = abNode;
        else if (abNode?._) abstract = abNode._;
        else if (Array.isArray(abNode)) abstract = abNode.map((n) => (typeof n === 'string' ? n : n?._ || '')).join(' ');

        // Year
        const pd = art?.Journal?.JournalIssue?.PubDate;
        const year = pd?.Year || String(pd?.MedlineDate || '').substring(0, 4) || 'N/A';

        return {
          id: pmid ? `pubmed_${pmid}` : null,
          title: art?.ArticleTitle?._ || art?.ArticleTitle || 'No title',
          abstract: abstract.substring(0, 600) || 'Abstract not available',
          authors,
          year,
          source: 'PubMed',
          url: pmid ? `https://pubmed.ncbi.nlm.nih.gov/${pmid}/` : null,
          relevanceScore: 0
        };
      } catch { return null; }
    }).filter((a) => a && a.id && a.title !== 'No title');
  } catch (err) {
    console.error('PubMed error:', err.message);
    return [];
  }
}

module.exports = { searchPubMed };
