const axios = require('axios');

const BASE = 'https://api.openalex.org/works';

async function searchOpenAlex(query, perPage = 100) {
  try {
    const res = await axios.get(BASE, {
      params: {
        search: query,
        'per-page': perPage,
        page: 1,
        sort: 'relevance_score:desc',
        filter: 'from_publication_date:2015-01-01',
        select: 'id,title,abstract_inverted_index,authorships,publication_year,primary_location,doi,open_access'
      },
      headers: { 'User-Agent': 'Curalink/1.0 (mailto:dev@curalink.app)' },
      timeout: 15000
    });

    return (res.data?.results || []).map((work) => {
      // Reconstruct abstract from inverted index
      let abstract = '';
      if (work.abstract_inverted_index) {
        try {
          const words = [];
          for (const [word, positions] of Object.entries(work.abstract_inverted_index)) {
            for (const pos of positions) words[pos] = word;
          }
          abstract = words.filter(Boolean).join(' ').substring(0, 600);
        } catch { abstract = ''; }
      }

      const authors = (work.authorships || []).slice(0, 5).map((a) => a?.author?.display_name).filter(Boolean);
      const src = work.primary_location?.source?.display_name || 'OpenAlex';
      const url = work.doi ? `https://doi.org/${work.doi.replace('https://doi.org/', '')}` : work.id;

      return {
        id: work.id ? `openalex_${work.id.split('/').pop()}` : null,
        title: work.title || 'No title',
        abstract: abstract || 'Abstract not available',
        authors,
        year: work.publication_year || 'N/A',
        source: `OpenAlex (${src})`,
        url: url || work.id,
        isOpenAccess: work.open_access?.is_oa || false,
        relevanceScore: 0
      };
    }).filter((w) => w.id && w.title !== 'No title');
  } catch (err) {
    console.error('OpenAlex error:', err.message);
    return [];
  }
}

module.exports = { searchOpenAlex };
