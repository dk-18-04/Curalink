const axios = require('axios');

const OLLAMA_BASE = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const MODEL = process.env.OLLAMA_MODEL || 'mistral';

async function isOllamaAvailable() {
  try {
    await axios.get(`${OLLAMA_BASE}/api/tags`, { timeout: 3000 });
    return true;
  } catch { return false; }
}

async function callOllama(systemPrompt, userPrompt) {
  const res = await axios.post(
    `${OLLAMA_BASE}/api/chat`,
    {
      model: MODEL,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      stream: false,
      options: { temperature: 0.3, top_p: 0.9, num_predict: 1200 }
    },
    { timeout: 120000 }
  );
  return res.data?.message?.content || '';
}

async function expandQuery(userQuery, disease) {
  const system = `You are a medical search query expert. Expand the given query into a precise PubMed-style search string combining disease, synonyms, and medical terms. Return ONLY the query string, nothing else.`;
  const prompt = `Disease: "${disease}"\nUser query: "${userQuery}"\n\nExpand into a comprehensive search query:`;
  try {
    const available = await isOllamaAvailable();
    if (!available) return disease ? `${disease} ${userQuery}` : userQuery;
    const result = await callOllama(system, prompt);
    return result.trim().substring(0, 250) || `${disease} ${userQuery}`;
  } catch {
    return disease ? `${disease} ${userQuery}` : userQuery;
  }
}

async function generateMedicalResponse({ userQuery, disease, patientName, location, publications, clinicalTrials, conversationHistory = [] }) {
  const system = `You are Curalink, an expert AI medical research assistant. You synthesize peer-reviewed research into clear, structured, personalized answers.

RULES:
- Only make claims supported by the provided research data
- Never hallucinate medical facts or treatments
- Cite specific publications (use [1], [2], etc.)
- Always recommend consulting healthcare professionals
- Be warm, clear, and empathetic
- Personalize to the patient's context

ALWAYS respond in this exact format:

## Condition Overview
[2-3 sentences about the condition as it relates to the query]

## Key Research Insights
[4-5 bullet points from publications, cite sources like [1], [2]]

## Clinical Trial Opportunities
[Summary of relevant trials, or note if none found]

## Personalized Recommendations
[Advice tailored to patient's disease/location/context]

## ⚠️ Medical Disclaimer
This is for research and educational purposes only. Always consult a qualified healthcare professional before making any medical decisions.`;

  const pubContext = publications.slice(0, 6).map((p, i) =>
    `[${i + 1}] "${p.title}" — ${p.source}, ${p.year}\nAbstract: ${p.abstract?.substring(0, 200)}...`
  ).join('\n\n');

  const trialContext = clinicalTrials.slice(0, 4).map((t, i) =>
    `[T${i + 1}] "${t.title}" | Status: ${t.status} | Phase: ${t.phase}`
  ).join('\n');

  const history = conversationHistory.slice(-4).map((m) =>
    `${m.role === 'user' ? 'Patient' : 'Assistant'}: ${m.content.substring(0, 150)}`
  ).join('\n');

  const prompt = `PATIENT CONTEXT:
Name: ${patientName || 'Anonymous'}
Disease: ${disease || 'Not specified'}
Location: ${location || 'Not specified'}
Current Query: "${userQuery}"

PRIOR CONVERSATION:
${history || 'None'}

PUBLICATIONS RETRIEVED (${publications.length} total):
${pubContext || 'No publications found.'}

CLINICAL TRIALS (${clinicalTrials.length} total):
${trialContext || 'No trials found.'}

Generate a structured, research-backed response:`;

  try {
    const available = await isOllamaAvailable();
    if (!available) return buildFallbackResponse({ userQuery, disease, publications, clinicalTrials });
    return await callOllama(system, prompt);
  } catch (err) {
    console.error('LLM error:', err.message);
    return buildFallbackResponse({ userQuery, disease, publications, clinicalTrials });
  }
}

function buildFallbackResponse({ userQuery, disease, publications, clinicalTrials }) {
  const pubLines = publications.slice(0, 5).map((p, i) =>
    `- **[${i + 1}] ${p.title}** (${p.source}, ${p.year})\n  ${p.abstract?.substring(0, 180)}...`
  ).join('\n\n');

  const trialLines = clinicalTrials.slice(0, 3).map((t) =>
    `- **${t.title}** — Status: **${t.status}** | Phase: ${t.phase}`
  ).join('\n');

  return `## Condition Overview
Based on your query about **${disease || userQuery}**, I've retrieved and ranked the most relevant research from PubMed, OpenAlex, and ClinicalTrials.gov.

## Key Research Insights
${pubLines || '- No relevant publications were found. Try refining your query with more specific medical terms.'}

## Clinical Trial Opportunities
${trialLines || '- No active clinical trials matched this query. Check ClinicalTrials.gov directly for the latest listings.'}

## Personalized Recommendations
Review the publications listed below for detailed findings. If any clinical trials are relevant to your situation, consult the contact information provided and speak with your physician about eligibility.

## ⚠️ Medical Disclaimer
This is for research and educational purposes only. Always consult a qualified healthcare professional before making any medical decisions.`;
}

module.exports = { expandQuery, generateMedicalResponse, isOllamaAvailable };
