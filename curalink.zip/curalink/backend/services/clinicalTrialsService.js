const axios = require('axios');

const BASE = 'https://clinicaltrials.gov/api/v2/studies';

async function searchClinicalTrials(disease, additionalQuery = '', location = '') {
  try {
    const FIELDS = [
      'NCTId','BriefTitle','OfficialTitle','OverallStatus','BriefSummary',
      'EligibilityCriteria','MinimumAge','MaximumAge','Sex',
      'LocationFacility','LocationCity','LocationCountry',
      'CentralContactName','CentralContactPhone','CentralContactEMail',
      'StartDate','CompletionDate','Phase','StudyType',
      'InterventionName','InterventionType'
    ].join(',');

    const baseParams = { 'query.cond': disease, format: 'json', fields: FIELDS };
    if (additionalQuery) baseParams['query.term'] = additionalQuery;
    if (location) baseParams['query.locn'] = location;

    // Fetch recruiting + completed in parallel
    const [recruiting, completed] = await Promise.allSettled([
      axios.get(BASE, { params: { ...baseParams, 'filter.overallStatus': 'RECRUITING', pageSize: 25 }, timeout: 15000 }),
      axios.get(BASE, { params: { ...baseParams, pageSize: 25 }, timeout: 15000 })
    ]);

    const all = [
      ...(recruiting.status === 'fulfilled' ? recruiting.value.data?.studies || [] : []),
      ...(completed.status === 'fulfilled' ? completed.value.data?.studies || [] : [])
    ];

    // Deduplicate
    const seen = new Set();
    const unique = all.filter((s) => {
      const id = s?.protocolSection?.identificationModule?.nctId;
      if (!id || seen.has(id)) return false;
      seen.add(id); return true;
    });

    return unique.map((study) => {
      const p = study?.protocolSection;
      const idM   = p?.identificationModule || {};
      const statM = p?.statusModule || {};
      const descM = p?.descriptionModule || {};
      const eligM = p?.eligibilityModule || {};
      const contM = p?.contactsLocationsModule || {};
      const desM  = p?.designModule || {};

      const locs = (contM.locations || []).slice(0, 3).map((l) => ({
        facility: l.facility, city: l.city, country: l.country
      }));
      const contact = (contM.centralContacts || [])[0] || {};

      return {
        id: idM.nctId,
        title: idM.briefTitle || idM.officialTitle || 'No title',
        status: statM.overallStatus || 'Unknown',
        summary: (descM.briefSummary || 'No summary').substring(0, 400),
        eligibility: (eligM.eligibilityCriteria || 'Not specified').substring(0, 500),
        minAge: eligM.minimumAge,
        maxAge: eligM.maximumAge,
        sex: eligM.sex,
        phase: (desM.phases || []).join(', ') || 'N/A',
        studyType: desM.studyType || 'N/A',
        startDate: statM.startDateStruct?.date,
        completionDate: statM.primaryCompletionDateStruct?.date,
        locations: locs,
        contact: { name: contact.name, phone: contact.phone, email: contact.email },
        url: `https://clinicaltrials.gov/study/${idM.nctId}`,
        source: 'ClinicalTrials.gov',
        relevanceScore: 0
      };
    }).filter((t) => t.id);
  } catch (err) {
    console.error('ClinicalTrials error:', err.message);
    return [];
  }
}

module.exports = { searchClinicalTrials };
